import argparse
import pandas as pd
import re
from pydriller import Repository

FIX_RE = re.compile(r"(fix|bug|issue|defect|patch)", re.I)

def label(repo_path: str) -> pd.DataFrame:
    flagged = set()
    for commit in Repository(repo_path).traverse_commits():
        msg = commit.msg or ""
        if FIX_RE.search(msg):
            for m in commit.modified_files:
                fpath = m.new_path or m.old_path
                if fpath and fpath.endswith('.py'):
                    flagged.add(fpath)
    return pd.DataFrame({"file": list(flagged), "defect_prone": 1})

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", required=True, help="Path to a local git repository")
    ap.add_argument("--out", required=True, help="Output labels CSV path")
    args = ap.parse_args()

    df = label(args.repo)
    df.to_csv(args.out, index=False)
    print(f"[labeler] Wrote: {args.out} ({len(df)} flagged files)")

if __name__ == "__main__":
    main()
