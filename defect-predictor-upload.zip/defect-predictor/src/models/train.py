import argparse
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_auc_score, average_precision_score, f1_score
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
import joblib
import os

EXCLUDE = {"file", "defect_prone", "last_ts"}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--features", nargs="+", required=True, help="CSV(s) with features to merge on 'file'")
    ap.add_argument("--labels", required=True, help="CSV with 'file' and 'defect_prone' (0/1)")
    ap.add_argument("--out", required=True, help="Output directory for models & metrics")
    args = ap.parse_args()

    df = None
    for f in args.features:
        part = pd.read_csv(f)
        df = part if df is None else df.merge(part, on="file", how="outer")
    labels = pd.read_csv(args.labels)
    df = df.merge(labels, on="file", how="left").fillna({"defect_prone": 0})

    feats = [c for c in df.columns if c not in EXCLUDE]
    X = df[feats].fillna(0)
    y = df["defect_prone"].astype(int)

    Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.2, stratify=y, random_state=42)

    models = {
        "logreg": LogisticRegression(max_iter=1000, class_weight="balanced"),
        "rf": RandomForestClassifier(n_estimators=300, class_weight="balanced", random_state=42)
    }

    os.makedirs(args.out, exist_ok=True)
    rows = []
    for name, model in models.items():
        model.fit(Xtr, ytr)
        p = model.predict_proba(Xte)[:, 1]
        auc = roc_auc_score(yte, p)
        pr = average_precision_score(yte, p)
        f1 = f1_score(yte, (p > 0.5).astype(int))
        rows.append((name, auc, pr, f1))
        joblib.dump(model, os.path.join(args.out, f"{name}.pkl"))

    pd.DataFrame(rows, columns=["model", "ROC_AUC", "PR_AUC", "F1"]).to_csv(
        os.path.join(args.out, "metrics.csv"), index=False
    )
    print(f"[train] Saved models & metrics to {args.out}")

if __name__ == "__main__":
    main()
