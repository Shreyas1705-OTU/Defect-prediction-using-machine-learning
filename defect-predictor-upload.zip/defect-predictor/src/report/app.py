from flask import Flask, render_template_string
import pandas as pd
import os

app = Flask(__name__)

TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Defect Risk Dashboard</title>
<style>
body{font-family:system-ui,Arial,sans-serif; margin:2rem;}
table{border-collapse:collapse;width:100%;}
th,td{border:1px solid #ddd;padding:8px;font-size:14px;}
th{background:#f4f4f4;cursor:pointer;}
</style>
</head>
<body>
<h1>Defect Risk Dashboard</h1>
{% if table %}
  {{ table|safe }}
{% else %}
  <p>No <code>reports/risk.csv</code> found. Generate it first.</p>
{% endif %}
</body>
</html>
"""

@app.route('/')
def index():
    path = os.path.join('reports', 'risk.csv')
    if os.path.exists(path):
        df = pd.read_csv(path).sort_values('risk', ascending=False)
        table = df.head(200).to_html(index=False)
    else:
        table = None
    return render_template_string(TEMPLATE, table=table)

if __name__ == '__main__':
    app.run(debug=True)
