import os
import ast
import subprocess
import pandas as pd
import numpy as np
from radon.complexity import cc_visit
from radon.metrics import mi_visit

# 📁 Paths
TARGET_DIR = "target_repo"
OUTPUT_FILE = "data/static.csv"


# -------------------------------------------------------------
# Function: Compute PEP8 Violations
# -------------------------------------------------------------
def compute_pep8_score(file_path):
    """Compute total PEP8 violations using pycodestyle, with fallback."""
    try:
        import pycodestyle
        style_guide = pycodestyle.StyleGuide(quiet=True)
        report = style_guide.check_files([file_path])
        return report.total_errors
    except Exception:
        try:
            result = subprocess.run(
                ["pycodestyle", file_path],
                capture_output=True,
                text=True,
                check=False
            )
            return len([l for l in result.stdout.splitlines() if ":" in l])
        except Exception as e:
            print(f"⚠️ Skipping PEP8 check for {file_path}: {e}")
            return 0


# -------------------------------------------------------------
# Function: Extract Static Metrics
# -------------------------------------------------------------
def extract_static_metrics(file_path):
    """Extract LOC, complexity, MI, and PEP8 metrics with robust encoding fallback."""
    try:
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                source = f.read()
        except UnicodeDecodeError:
            with open(file_path, "r", encoding="latin-1", errors="ignore") as f:
                source = f.read()
    except Exception as e:
        print(f"⚠️ Skipping unreadable file: {file_path} ({e})")
        return None

    # Skip empty files
    if len(source.strip()) < 5:
        return {"file": os.path.relpath(file_path, TARGET_DIR), "loc": 0, "avg_cc": 0, "mi": 0, "pep8": 0}

    try:
        loc = len(source.splitlines())
        complexities = cc_visit(source)
        avg_cc = np.mean([c.complexity for c in complexities]) if complexities else 0
        mi_score = mi_visit(source, True)
        pep8_violations = compute_pep8_score(file_path)

        return {
            "file": os.path.relpath(file_path, TARGET_DIR),
            "loc": loc,
            "avg_cc": avg_cc,
            "mi": mi_score,
            "pep8": pep8_violations
        }
    except Exception as e:
        print(f"⚠️ Failed metrics for {file_path}: {e}")
        return {"file": os.path.relpath(file_path, TARGET_DIR), "loc": 0, "avg_cc": 0, "mi": 0, "pep8": 0}


# -------------------------------------------------------------
# Function: Walk Repo
# -------------------------------------------------------------
def scan_repo(repo_dir):
    """Walk repository, extract metrics for all Python files."""
    records = []
    skipped = 0
    for root, _, files in os.walk(repo_dir):
        for file in files:
            if file.endswith(".py"):
                full_path = os.path.join(root, file)
                metrics = extract_static_metrics(full_path)
                if metrics:
                    records.append(metrics)
                else:
                    skipped += 1
    print(f"✅ Processed {len(records)} files | ⚠️ Skipped {skipped} files")
    return pd.DataFrame(records)


# -------------------------------------------------------------
# MAIN
# -------------------------------------------------------------
if __name__ == "__main__":
    print(f"🔍 Starting static analysis in: {TARGET_DIR}")
    df = scan_repo(TARGET_DIR)

    if df.empty:
        print("⚠️ No static metrics extracted. Check target_repo path.")
    else:
        os.makedirs(os.path.dirname(OUTPUT_FILE), exist_ok=True)
        df = df.fillna(0)
        df.to_csv(OUTPUT_FILE, index=False)
        print(f"✅ [static_metrics] Wrote: {OUTPUT_FILE} ({len(df)} files)")
        print(df.head(10))
